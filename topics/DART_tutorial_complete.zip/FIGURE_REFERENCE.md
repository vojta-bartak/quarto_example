# DART Tutorial - Figure Reference Table

Quick reference for all 18 figures used in the tutorial.

| # | Filename | PDF Page | Section | Description |
|---|----------|----------|---------|-------------|
| 1 | `fig01_new_simulation.png` | 1 | Initial Setup | New simulation dialog and menu |
| 2 | `fig02_open_editor.png` | 2 | Initial Setup | Opening the Parameters Editor |
| 3 | `fig03_basic_config.png` | 3 | Core Parameters | Basic configuration with atmosphere and threading |
| 4 | `fig04_spectral_bands.png` | 4 | Core Parameters | Four spectral band configuration dialogs |
| 5 | `fig05_bidirectional_params.png` | 5 | Scene Configuration | Bi-directional rendering parameters |
| 6 | `fig06_products_config.png` | 6 | Scene Configuration | Output products and format settings |
| 7 | `fig07_leaves_optical.png` | 7 | Optical Properties | PROSPECT model for leaves |
| 8 | `fig08_bark_optical.png` | 8 | Optical Properties | Bark optical properties from database |
| 9 | `fig09_ground_optical.png` | 9 | Optical Properties | Forest floor optical properties |
| 10 | `fig10_earth_scene.png` | 10 | Earth Scene | Scene dimensions and geographic location |
| 11 | `fig11_field_import.png` | 11 | 3D Objects | Field file import dialog |
| 12 | `fig12_3d_model_import.png` | 12 | 3D Objects | 3D tree model import interface |
| 13 | `fig13_leaves_config.png` | 13 | 3D Objects | Leaves group configuration with 2D view |
| 14 | `fig14_woody_parts_config.png` | 14 | 3D Objects | Woody parts group configuration |
| 15 | `fig15_complete_scene.png` | 15 | 3D Objects | Complete 2D scene with all trees |
| 16 | `fig16_atmosphere_config.png` | 16 | Atmosphere | Atmospheric parameters (optional) |
| 17 | `fig17_run_modules.png` | 17 | Running Simulation | Run menu with DART modules |
| 18 | `fig18_sequence_launcher.png` | 18 | Sequence Launcher | LUT generation interface |

## Figure Usage in Tutorial

### Critical Figures (Must Have)
These figures are essential for following the tutorial:
- Fig 1, 2: Navigation and initial setup
- Fig 3-6: Core configuration parameters
- Fig 7-9: Optical properties (key for understanding RTM)
- Fig 11-15: 3D scene setup (main workflow)
- Fig 17: Running simulations

### Supplementary Figures (Nice to Have)
These figures provide additional context:
- Fig 10: Earth scene (mostly repetitive of earlier steps)
- Fig 16: Atmosphere (marked as optional in tutorial)
- Fig 18: Sequence Launcher (advanced topic)

## Figure Quality Requirements

### Minimum Requirements
- **Resolution:** 1200px width minimum
- **Format:** PNG (lossless)
- **File size:** < 2 MB per image (for web performance)
- **DPI:** 150+ for print quality

### Recommended
- **Resolution:** 1920px width for screenshots
- **Cropping:** Remove unnecessary UI elements, focus on relevant panels
- **Annotations:** Highlight key settings (optional, can be done in editing)

## Cross-References in Text

Each figure is referenced in the tutorial using Quarto's cross-reference syntax:

```markdown
![Caption text](images/figNN_name.png){#fig-label}

...

As shown in @fig-label, the configuration...
```

This automatically:
- Numbers figures sequentially
- Creates clickable links
- Updates references if figures are reordered

## Checklist for Image Preparation

- [ ] All 18 images extracted from PDF
- [ ] Images saved in `images/` folder
- [ ] Filenames match exactly (case-sensitive)
- [ ] PNG format used for all images
- [ ] Images are clear and readable
- [ ] No compression artifacts
- [ ] Resolution is adequate (1200px+ width)
- [ ] Optional: Cropped to show only relevant content

## Testing Image References

After adding images, test the tutorial:

```bash
# Quick check - render to HTML
quarto render DART_tutorial.qmd --to html

# Open in browser and verify:
# 1. All images display correctly
# 2. Cross-references work (clickable)
# 3. Figure numbers are sequential
# 4. Images are appropriately sized
```

## Alternative Image Sources

If PDF extraction is not possible or quality is insufficient:

1. **Direct Screenshots:** Capture directly from DART application
   - Pros: Best quality, customizable
   - Cons: Requires DART installation and setup

2. **Request from Original Author:** Contact tutorial creator for source images
   - Pros: Original quality
   - Cons: May not be available

3. **Recreate in DART:** Follow tutorial steps and capture your own
   - Pros: Latest DART version, verified workflow
   - Cons: Time-consuming, requires DART setup

## Image Attribution

If using images from the original PDF:
- Maintain original copyright notices
- Attribute to original authors
- Follow any specified usage restrictions

---

*For detailed extraction instructions, see IMAGE_EXTRACTION_GUIDE.md*
