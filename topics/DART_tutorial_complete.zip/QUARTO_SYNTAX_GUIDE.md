# Quarto Syntax Guide for DART Tutorial Customization

This guide provides common Quarto markdown patterns used in the DART tutorial and how to customize them.

## Table of Contents
- [Callout Boxes](#callout-boxes)
- [Figures and Cross-References](#figures-and-cross-references)
- [Tables](#tables)
- [Panel Tabsets](#panel-tabsets)
- [Code Blocks](#code-blocks)
- [Lists and Formatting](#lists-and-formatting)
- [YAML Front Matter](#yaml-front-matter)

---

## Callout Boxes

Callout boxes highlight important information in different colors.

### Note (Blue)
```markdown
::: callout-note
## Optional Title
Regular informational content.
:::
```

### Tip (Green)
```markdown
::: callout-tip
## Pro Tip
Helpful suggestions and best practices.
:::
```

### Important (Red)
```markdown
::: callout-important
## Critical Information
Must-read information that affects outcomes.
:::
```

### Warning (Orange/Yellow)
```markdown
::: callout-warning
## Warning
Cautions about potential problems.
:::
```

### Caution (Yellow)
```markdown
::: callout-caution
## Proceed Carefully
Similar to warning, but less severe.
:::
```

### Custom Icons
```markdown
::: {.callout-note icon=false}
## No Icon
Callout without an icon.
:::
```

---

## Figures and Cross-References

### Basic Figure
```markdown
![Figure caption goes here](path/to/image.png)
```

### Figure with Label (Numbered)
```markdown
![Figure caption goes here](images/my_figure.png){#fig-label}
```

### Referencing Figures in Text
```markdown
As shown in @fig-label, the configuration requires...

See @fig-label for details.

Compare @fig-label-1 with @fig-label-2.
```

### Figure with Custom Width
```markdown
![Caption](image.png){#fig-label width=80%}

![Caption](image.png){#fig-label width=400px}
```

### Figure with Alt Text
```markdown
![Caption](image.png){#fig-label fig-alt="Detailed description for screen readers"}
```

### Side-by-Side Figures
```markdown
::: {#fig-comparison layout-ncol=2}

![Caption A](image1.png){#fig-first}

![Caption B](image2.png){#fig-second}

Side-by-side comparison
:::
```

---

## Tables

### Basic Markdown Table
```markdown
| Column 1 | Column 2 | Column 3 |
|----------|----------|----------|
| Value A  | Value B  | Value C  |
| Value D  | Value E  | Value F  |
```

### Table with Alignment
```markdown
| Left | Center | Right |
|:-----|:------:|------:|
| L1   | C1     | R1    |
| L2   | C2     | R2    |
```

### Table with Caption
```markdown
| Col1 | Col2 |
|------|------|
| A    | B    |

: Table caption {#tbl-label}
```

### Referencing Tables
```markdown
See @tbl-label for parameter values.
```

---

## Panel Tabsets

Panel tabsets organize related content into tabs.

### Basic Tabset
```markdown
::: panel-tabset
## Tab 1
Content for first tab.

## Tab 2
Content for second tab.

## Tab 3
Content for third tab.
:::
```

### Used in Tutorial
```markdown
::: panel-tabset
## Data Preprocessing
- Step 1
- Step 2

## Exploratory Analysis
- Analysis approach
- Visualization methods

## Model Validation
- Validation strategy
- Metrics to report
:::
```

---

## Code Blocks

### Simple Code Block
````markdown
```bash
echo "Hello World"
```
````

### Code Block with Syntax Highlighting
````markdown
```python
def hello():
    print("Hello World")
```
````

### Executable Code (R, Python)
````markdown
```{python}
#| label: my-code
#| eval: true
#| echo: true

import numpy as np
print(np.array([1, 2, 3]))
```
````

### Code Options
````markdown
```{python}
#| label: figure-name
#| fig-cap: "Figure caption"
#| fig-width: 8
#| fig-height: 6
#| eval: false  # Don't execute
#| echo: false  # Don't show code
#| warning: false  # Suppress warnings
#| message: false  # Suppress messages

# Code here
```
````

---

## Lists and Formatting

### Unordered Lists
```markdown
- Item 1
- Item 2
  - Nested item
  - Another nested
- Item 3
```

### Ordered Lists
```markdown
1. First step
2. Second step
   a. Sub-step
   b. Another sub-step
3. Third step
```

### Definition Lists
```markdown
Term 1
: Definition of term 1

Term 2
: Definition of term 2
```

### Task Lists
```markdown
- [ ] Unchecked item
- [x] Checked item
- [ ] Another item
```

### Bold and Italic
```markdown
**Bold text**
*Italic text*
***Bold and italic***
```

### Inline Code
```markdown
Use the `print()` function to display output.
```

### Links
```markdown
[Link text](https://example.com)
[Link with title](https://example.com "Hover text")
```

### Footnotes
```markdown
This is a statement.[^1]

[^1]: This is the footnote content.
```

---

## YAML Front Matter

### Basic Configuration
```yaml
---
title: "Document Title"
author: "Author Name"
date: today
format: html
---
```

### HTML Options
```yaml
---
format:
  html:
    toc: true              # Table of contents
    toc-depth: 3           # Heading depth (1-5)
    toc-location: left     # left, right, body
    number-sections: true  # Number headings
    code-fold: false       # Fold code blocks
    code-tools: true       # Show code tools
    theme: cosmo           # Bootstrap theme
    css: custom.css        # Custom CSS
    embed-resources: true  # Self-contained file
---
```

### PDF Options
```yaml
---
format:
  pdf:
    toc: true
    number-sections: true
    colorlinks: true
    geometry:
      - margin=1in
    fontsize: 11pt
    documentclass: article
---
```

### Multiple Formats
```yaml
---
format:
  html:
    toc: true
    theme: cosmo
  pdf:
    toc: true
    geometry: margin=1in
---
```

### Execution Options
```yaml
---
execute:
  warning: false    # Suppress warnings
  message: false    # Suppress messages
  echo: true        # Show code
  eval: true        # Execute code
  cache: true       # Cache results
---
```

---

## Advanced Patterns

### Conditional Content
```markdown
::: {.content-visible when-format="html"}
This only appears in HTML output.
:::

::: {.content-visible when-format="pdf"}
This only appears in PDF output.
:::
```

### Columns Layout
```markdown
::: {layout-ncol=2}
Left column content

Right column content
:::
```

### Custom Divs
```markdown
::: {.my-custom-class}
Content with custom CSS class
:::
```

### Margin Content
```markdown
Some text with a margin note. [This appears in margin]{.aside}
```

### Line Blocks
```markdown
| First line
| Second line preserving
|   indentation
```

---

## Customization Tips

### Changing Colors
Create a custom CSS file:

```css
/* custom.css */
.callout-note {
    border-left-color: #your-color;
}
```

Reference in YAML:
```yaml
format:
  html:
    css: custom.css
```

### Custom Themes
Available built-in themes:
- default, cerulean, cosmo, cyborg, darkly
- flatly, journal, litera, lumen, lux
- materia, minty, morph, pulse, quartz
- sandstone, simplex, sketchy, slate, solar
- spacelab, superhero, united, vapor, yeti, zephyr

### Figure Numbering Style
```yaml
format:
  html:
    number-sections: true
    crossref:
      fig-prefix: "Figure"
      tbl-prefix: "Table"
```

---

## Troubleshooting

### Images Not Showing
- Check relative paths
- Verify image files exist
- Ensure correct file extensions
- Check for case-sensitive filenames

### Cross-References Not Working
- Ensure labels start with `#fig-`, `#tbl-`, etc.
- Use `@` before label name in text
- Check for duplicate labels

### Rendering Errors
- Validate YAML syntax (indentation matters!)
- Check for unclosed div blocks (`::: ... :::`)
- Verify code block syntax
- Look for special characters that need escaping

---

## Resources

- [Quarto Documentation](https://quarto.org/docs/guide/)
- [Markdown Basics](https://quarto.org/docs/authoring/markdown-basics.html)
- [Cross References](https://quarto.org/docs/authoring/cross-references.html)
- [Figures](https://quarto.org/docs/authoring/figures.html)
- [Tables](https://quarto.org/docs/authoring/tables.html)
- [Callouts](https://quarto.org/docs/authoring/callouts.html)
- [HTML Themes](https://quarto.org/docs/output-formats/html-themes.html)

---

*For more examples, see the DART_tutorial.qmd source file.*
