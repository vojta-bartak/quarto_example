# DART Tutorial - Image Extraction Guide

This document provides detailed instructions for extracting the required images from the original DART_tutorial_CZU_summer_school.pdf file.

## Image List and Sources

All images should be saved in the `images/` folder with the specified filenames.

### Figure 1: New Simulation Dialog
**Filename:** `fig01_new_simulation.png`
**Source:** Page 1 of PDF
**Content:** 
- DART main window with Simulation menu open
- Shows "New Simulation" dialog box
- Includes simulation name field and file browser
**Screenshot should capture:**
- The entire DART main menu bar
- The opened Simulation menu dropdown
- The "New simulation" dialog with folder structure and name input

---

### Figure 2: Open Editor
**Filename:** `fig02_open_editor.png`
**Source:** Page 2 of PDF
**Content:**
- DART main window showing Parameters menu
- Editor option highlighted
- Shows the parameters window structure
**Screenshot should capture:**
- Parameters menu with "Editor" option visible
- The initial editor interface

---

### Figure 3: Basic Configuration
**Filename:** `fig03_basic_config.png`
**Source:** Page 3 of PDF
**Content:**
- DART Simulation Editor main window
- Left panel showing parameter tree structure
- Right panel showing:
  - Atmosphere settings (checkbox checked)
  - Advanced mode checkbox
  - Number of threads setting (12)
  - Iteration/TOA parameters
  - Radiative Transfer (RT) options
**Screenshot should capture:**
- Full editor window
- Highlighted/visible settings: Advanced mode, Number of threads (12)

---

### Figure 4: Spectral Bands Configuration
**Filename:** `fig04_spectral_bands.png`
**Source:** Page 4 of PDF
**Content:**
- Four small dialog boxes showing spectral band configurations
- Each dialog shows:
  - Spectral band number (0, 1, 2, 3)
  - Mode (Mode R)
  - Central wavelength
  - Spectral bandwidth
**Screenshot should capture:**
- All four configuration dialogs arranged in a grid
- Clear visibility of wavelength and bandwidth values

---

### Figure 5: Bi-directional Parameters
**Filename:** `fig05_bidirectional_params.png`
**Source:** Page 5 of PDF
**Content:**
- Bi-directional parameters panel
- Shows settings for:
  - Target pixel size [m]: 0.05
  - Target sample density: 50
  - Maximal rendering time: 2000
  - Russian Roulette Acceleration (checked)
  - Periodic save method: No periodic save
- Grid view of scene in center
**Screenshot should capture:**
- Right panel with all highlighted parameters
- Clear visibility of numeric values

---

### Figure 6: Products Configuration
**Filename:** `fig06_products_config.png`
**Source:** Page 6 of PDF
**Content:**
- Products → BRF/BTF section
- Shows:
  - "Write BRF/BTF files and maps" checkbox
  - Type of color/model selection
  - Images format options (Ilwis and netcdf)
  - Maximal VZA: 1.0
**Screenshot should capture:**
- Full BRF/BTF configuration panel
- All relevant checkboxes and dropdown menus

---

### Figure 7: Leaves Optical Properties
**Filename:** `fig07_leaves_optical.png`
**Source:** Page 7 of PDF
**Content:**
- Lambertian optical properties configuration
- Left panel showing "(2) Lambertian" tree structure
- Right panel showing:
  - Lambertian property name: "leaves"
  - Multiplicative factor (unchecked)
  - Prospect section (Reflectance, transmittance checked)
  - PROSPECT parameters (Structure coefficient, Chlorophyll, etc.)
**Screenshot should capture:**
- Full configuration window
- Clear visibility of PROSPECT parameters

---

### Figure 8: Bark Optical Properties
**Filename:** `fig08_bark_optical.png`
**Source:** Page 8 of PDF
**Content:**
- Lambertian optical properties for bark
- Shows:
  - Lambertian property name: "bark"
  - 2D lambertian database: lanzhot_materials.db
  - 2D lambertian model: trunk_FA_SY_QE_sp_Lanzhot_fix
**Screenshot should capture:**
- Configuration panel with database selection
- Dropdown menus showing database and model names

---

### Figure 9: Ground Optical Properties
**Filename:** `fig09_ground_optical.png`
**Source:** Page 9 of PDF
**Content:**
- Similar to Figure 8 but for ground
- Shows:
  - Lambertian property name: "ground"
  - 2D lambertian model: forestfloor_LZ_mod_fix_txt
- Context menu showing "Remove" and "Duplicate" options
**Screenshot should capture:**
- Configuration panel
- Right-click context menu (if visible)

---

### Figure 10: Earth Scene Configuration
**Filename:** `fig10_earth_scene.png`
**Source:** Page 10 of PDF
**Content:**
- Earth Scene parameters panel
- Shows:
  - Scene dimensions (X max: 30, Y max: 30)
  - Ground optical property selection: "ground"
  - Geo-Location section with altitude, latitude, longitude
**Screenshot should capture:**
- Full Earth Scene configuration panel
- All highlighted parameters clearly visible

---

### Figure 11: Field Import
**Filename:** `fig11_field_import.png`
**Source:** Page 11 of PDF
**Content:**
- Object fields section in left tree
- Field import dialog showing:
  - Field description file selection (beech.txt)
  - Name field
  - "Show this field's objects in the 2D view" checkbox
**Screenshot should capture:**
- Left tree structure showing Object fields
- Field configuration dialog

---

### Figure 12: 3D Model Import
**Filename:** `fig12_3d_model_import.png`
**Source:** Page 12 of PDF
**Content:**
- 3D Models import interface
- Shows:
  - Source file path
  - Name field: "beech_20"
  - Object's color selector
  - Various checkboxes and options
**Screenshot should capture:**
- Full 3D model import dialog
- Color selector if visible

---

### Figure 13: Leaves Configuration
**Filename:** `fig13_leaves_config.png`
**Source:** Page 13 of PDF
**Content:**
- 3D object group configuration for leaves
- Left panel showing expanded tree structure with groups
- Right panel showing:
  - Group name: "leaves"
  - Double face checkbox (checked)
  - Optical property assignment: "leaves"
- 2D view showing orange/colored circles (tree crowns)
**Screenshot should capture:**
- Left tree with expanded groups
- Right configuration panel
- 2D scene view with colored circles

---

### Figure 14: Woody Parts Configuration
**Filename:** `fig14_woody_parts_config.png`
**Source:** Page 14 of PDF
**Content:**
- Similar to Figure 13 but for wooden parts
- Shows:
  - Group name: "wooden_parts"
  - Double face checkbox
  - Optical property: "bark"
  - Color selector set to trunk color
- 2D view with scene
**Screenshot should capture:**
- Configuration panel for woody parts
- 2D scene view

---

### Figure 15: Complete Scene View
**Filename:** `fig15_complete_scene.png`
**Source:** Page 15 of PDF
**Content:**
- Large 2D scene view showing all imported trees
- Multiple colored circles representing different tree models
- Colors: blue, orange, red, green circles of various sizes
- Left panel showing all 4 imported models (beech_20, beech_27, beech_28, beech_62)
**Screenshot should capture:**
- Full 2D scene view with all trees visible
- Left tree structure showing all models
- Clear visibility of spatial distribution

---

### Figure 16: Atmosphere Configuration
**Filename:** `fig16_atmosphere_config.png`
**Source:** Page 16 of PDF
**Content:**
- Atmosphere configuration panel
- Shows extensive parameters:
  - Atmospheric database selection
  - Gas composition settings
  - Temperature profiles
  - Aerosol properties
  - Advanced mode zone settings
**Screenshot should capture:**
- Full atmosphere configuration panel
- Visibility of major parameter sections

---

### Figure 17: Run Modules
**Filename:** `fig17_run_modules.png`
**Source:** Page 17 of PDF
**Content:**
- DART main window with Run menu open
- Shows all modules:
  - DART
  - Direction
  - Phase
  - Maket
  - Dart
  - Atmosphere Creation
  - Cover map importation
  - Hapke
  - DEMGenerator
  - SequenceLauncher
**Screenshot should capture:**
- Run menu dropdown with all modules visible
- Clear module names and keyboard shortcuts

---

### Figure 18: Sequence Launcher
**Filename:** `fig18_sequence_launcher.png`
**Source:** Page 18 of PDF
**Content:**
- Three dialog windows:
  1. Main SequenceLauncher window (left) showing execution progress
  2. Properties group details (center) showing parameter tree
  3. Main Processes (right) showing module selection checkboxes
**Screenshot should capture:**
- All three windows arranged together
- Clear visibility of parameter selection tree and process options

---

## Extraction Tips

1. **Use a PDF viewer** that allows high-quality screenshot export (Adobe Acrobat, Preview on Mac, etc.)
2. **Resolution:** Save images at high enough resolution (at least 1200px wide) for clarity
3. **Format:** PNG format is preferred for screenshots
4. **Cropping:** Crop images to show relevant content while maintaining context
5. **File naming:** Use exact filenames as specified above
6. **Folder structure:** Create an `images/` folder in the same directory as the DART_tutorial.qmd file

## Verification Checklist

Before using the images, verify:
- [ ] All 18 images are present in the `images/` folder
- [ ] Filenames exactly match the specified names
- [ ] Images are clear and readable
- [ ] PNG format is used
- [ ] No compression artifacts that would reduce readability

## Alternative: Extracting from PDF Programmatically

If you prefer to extract images automatically from the PDF, you can use tools like:
- `pdfimages` (from poppler-utils)
- Python with `PyPDF2` or `pdf2image`
- Adobe Acrobat's export function

However, manual screenshots often provide better quality and control over what's captured.
