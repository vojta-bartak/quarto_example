#!/usr/bin/env python3
"""
DART Tutorial Image Extractor

This script helps extract images from the DART tutorial PDF.
It extracts one image per page and saves them with appropriate filenames.

Requirements:
    pip install pdf2image pillow

Note: On Linux, you may also need to install poppler-utils:
    sudo apt-get install poppler-utils
"""

import os
from pathlib import Path

try:
    from pdf2image import convert_from_path
    from PIL import Image
except ImportError:
    print("Error: Required packages not installed.")
    print("Please run: pip install pdf2image pillow")
    exit(1)

# Mapping of PDF pages to output filenames
PAGE_TO_FILENAME = {
    1: "fig01_new_simulation.png",
    2: "fig02_open_editor.png",
    3: "fig03_basic_config.png",
    4: "fig04_spectral_bands.png",
    5: "fig05_bidirectional_params.png",
    6: "fig06_products_config.png",
    7: "fig07_leaves_optical.png",
    8: "fig08_bark_optical.png",
    9: "fig09_ground_optical.png",
    10: "fig10_earth_scene.png",
    11: "fig11_field_import.png",
    12: "fig12_3d_model_import.png",
    13: "fig13_leaves_config.png",
    14: "fig14_woody_parts_config.png",
    15: "fig15_complete_scene.png",
    16: "fig16_atmosphere_config.png",
    17: "fig17_run_modules.png",
    18: "fig18_sequence_launcher.png",
}

def extract_images(pdf_path, output_dir="images", dpi=200):
    """
    Extract images from PDF, one per page.
    
    Args:
        pdf_path: Path to the input PDF file
        output_dir: Directory to save extracted images
        dpi: Resolution for image extraction (higher = better quality, larger files)
    """
    # Create output directory
    output_path = Path(output_dir)
    output_path.mkdir(exist_ok=True)
    
    print(f"Converting PDF to images at {dpi} DPI...")
    print(f"This may take a moment...\n")
    
    # Convert PDF pages to images
    try:
        images = convert_from_path(pdf_path, dpi=dpi)
    except Exception as e:
        print(f"Error converting PDF: {e}")
        print("\nIf you see an error about poppler, you may need to install it:")
        print("  - macOS: brew install poppler")
        print("  - Ubuntu/Debian: sudo apt-get install poppler-utils")
        print("  - Windows: Download from https://github.com/oschwartz10612/poppler-windows/releases/")
        return
    
    print(f"Extracted {len(images)} pages from PDF\n")
    
    # Save each page with the corresponding filename
    for page_num, image in enumerate(images, start=1):
        if page_num in PAGE_TO_FILENAME:
            filename = PAGE_TO_FILENAME[page_num]
            output_file = output_path / filename
            
            # Save the image
            image.save(output_file, "PNG", optimize=True)
            print(f"✓ Saved page {page_num:2d} as {filename}")
        else:
            print(f"⊘ Skipped page {page_num:2d} (not needed)")
    
    print(f"\n✓ All images saved to '{output_dir}/' directory")
    print("\nNote: You may want to manually crop these images to show only")
    print("the relevant UI elements. See IMAGE_EXTRACTION_GUIDE.md for details.")

def main():
    """Main function."""
    import sys
    
    # Check for PDF file argument
    if len(sys.argv) < 2:
        print("Usage: python extract_images.py <path_to_pdf>")
        print("\nExample:")
        print("  python extract_images.py DART_tutorial_CZU_summer_school.pdf")
        print("\nThis will extract images to the 'images/' directory.")
        return
    
    pdf_path = sys.argv[1]
    
    # Check if PDF exists
    if not os.path.exists(pdf_path):
        print(f"Error: PDF file not found: {pdf_path}")
        return
    
    # Extract images
    extract_images(pdf_path)

if __name__ == "__main__":
    main()
