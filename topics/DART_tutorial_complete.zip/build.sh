#!/bin/bash

# DART Tutorial Build Script
# This script helps set up and render the DART tutorial

set -e  # Exit on error

# Color codes for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Print colored message
print_message() {
    local color=$1
    local message=$2
    echo -e "${color}${message}${NC}"
}

# Check if a command exists
command_exists() {
    command -v "$1" >/dev/null 2>&1
}

# Print header
print_header() {
    echo ""
    print_message "$BLUE" "============================================"
    print_message "$BLUE" "  DART Tutorial Build Script"
    print_message "$BLUE" "============================================"
    echo ""
}

# Check prerequisites
check_prerequisites() {
    print_message "$YELLOW" "Checking prerequisites..."
    
    local missing_deps=0
    
    # Check for Quarto
    if ! command_exists quarto; then
        print_message "$RED" "✗ Quarto not found"
        echo "  Install from: https://quarto.org/docs/get-started/"
        missing_deps=1
    else
        print_message "$GREEN" "✓ Quarto found: $(quarto --version)"
    fi
    
    # Check for Python (optional, for image extraction)
    if ! command_exists python3; then
        print_message "$YELLOW" "⚠ Python3 not found (optional, needed for automated image extraction)"
    else
        print_message "$GREEN" "✓ Python3 found: $(python3 --version 2>&1)"
    fi
    
    if [ $missing_deps -eq 1 ]; then
        print_message "$RED" "Please install missing dependencies before continuing."
        exit 1
    fi
    
    echo ""
}

# Extract images from PDF
extract_images() {
    local pdf_file="$1"
    
    if [ ! -f "$pdf_file" ]; then
        print_message "$RED" "Error: PDF file not found: $pdf_file"
        exit 1
    fi
    
    print_message "$YELLOW" "Extracting images from PDF..."
    
    # Check if Python script exists
    if [ ! -f "extract_images.py" ]; then
        print_message "$RED" "Error: extract_images.py not found"
        exit 1
    fi
    
    # Check Python dependencies
    python3 -c "import pdf2image, PIL" 2>/dev/null
    if [ $? -ne 0 ]; then
        print_message "$YELLOW" "Installing Python dependencies..."
        pip3 install pdf2image pillow
    fi
    
    # Run extraction
    python3 extract_images.py "$pdf_file"
    
    if [ $? -eq 0 ]; then
        print_message "$GREEN" "✓ Images extracted successfully"
    else
        print_message "$RED" "✗ Image extraction failed"
        exit 1
    fi
    
    echo ""
}

# Check if images exist
check_images() {
    print_message "$YELLOW" "Checking for required images..."
    
    if [ ! -d "images" ]; then
        print_message "$RED" "✗ Images directory not found"
        echo "  Please extract images first or create images/ folder manually"
        return 1
    fi
    
    local required_images=(
        "fig01_new_simulation.png"
        "fig02_open_editor.png"
        "fig03_basic_config.png"
        "fig04_spectral_bands.png"
        "fig05_bidirectional_params.png"
        "fig06_products_config.png"
        "fig07_leaves_optical.png"
        "fig08_bark_optical.png"
        "fig09_ground_optical.png"
        "fig10_earth_scene.png"
        "fig11_field_import.png"
        "fig12_3d_model_import.png"
        "fig13_leaves_config.png"
        "fig14_woody_parts_config.png"
        "fig15_complete_scene.png"
        "fig16_atmosphere_config.png"
        "fig17_run_modules.png"
        "fig18_sequence_launcher.png"
    )
    
    local missing=0
    for img in "${required_images[@]}"; do
        if [ ! -f "images/$img" ]; then
            print_message "$RED" "✗ Missing: $img"
            missing=$((missing + 1))
        fi
    done
    
    if [ $missing -eq 0 ]; then
        print_message "$GREEN" "✓ All ${#required_images[@]} images found"
        return 0
    else
        print_message "$RED" "✗ Missing $missing images"
        return 1
    fi
    
    echo ""
}

# Render tutorial
render_tutorial() {
    local format=$1
    
    print_message "$YELLOW" "Rendering tutorial to $format..."
    
    if [ ! -f "DART_tutorial.qmd" ]; then
        print_message "$RED" "Error: DART_tutorial.qmd not found"
        exit 1
    fi
    
    quarto render DART_tutorial.qmd --to $format
    
    if [ $? -eq 0 ]; then
        print_message "$GREEN" "✓ Tutorial rendered successfully"
        
        if [ "$format" = "html" ]; then
            local output_file="DART_tutorial.html"
            if [ -f "$output_file" ]; then
                print_message "$GREEN" "Output: $output_file"
            fi
        elif [ "$format" = "pdf" ]; then
            local output_file="DART_tutorial.pdf"
            if [ -f "$output_file" ]; then
                print_message "$GREEN" "Output: $output_file"
            fi
        fi
    else
        print_message "$RED" "✗ Rendering failed"
        exit 1
    fi
    
    echo ""
}

# Show usage
show_usage() {
    echo "Usage: $0 [command] [options]"
    echo ""
    echo "Commands:"
    echo "  check         Check prerequisites and images"
    echo "  extract PDF   Extract images from PDF file"
    echo "  render [fmt]  Render tutorial (html, pdf, or all)"
    echo "  build PDF     Complete workflow: extract + render HTML"
    echo "  help          Show this help message"
    echo ""
    echo "Examples:"
    echo "  $0 check"
    echo "  $0 extract DART_tutorial_CZU_summer_school.pdf"
    echo "  $0 render html"
    echo "  $0 build DART_tutorial_CZU_summer_school.pdf"
    echo ""
}

# Main script logic
main() {
    print_header
    
    case "${1:-help}" in
        check)
            check_prerequisites
            check_images
            ;;
        
        extract)
            if [ -z "$2" ]; then
                print_message "$RED" "Error: Please provide PDF filename"
                echo "Usage: $0 extract <pdf_file>"
                exit 1
            fi
            check_prerequisites
            extract_images "$2"
            ;;
        
        render)
            format="${2:-html}"
            if [ "$format" != "html" ] && [ "$format" != "pdf" ] && [ "$format" != "all" ]; then
                print_message "$RED" "Error: Invalid format. Use 'html', 'pdf', or 'all'"
                exit 1
            fi
            check_prerequisites
            check_images || print_message "$YELLOW" "Warning: Some images are missing. Rendering may fail."
            
            if [ "$format" = "all" ]; then
                render_tutorial "html"
                render_tutorial "pdf"
            else
                render_tutorial "$format"
            fi
            ;;
        
        build)
            if [ -z "$2" ]; then
                print_message "$RED" "Error: Please provide PDF filename"
                echo "Usage: $0 build <pdf_file>"
                exit 1
            fi
            check_prerequisites
            extract_images "$2"
            check_images
            render_tutorial "html"
            print_message "$GREEN" "✓ Build complete!"
            ;;
        
        help|--help|-h)
            show_usage
            ;;
        
        *)
            print_message "$RED" "Error: Unknown command '$1'"
            echo ""
            show_usage
            exit 1
            ;;
    esac
}

# Run main function
main "$@"
