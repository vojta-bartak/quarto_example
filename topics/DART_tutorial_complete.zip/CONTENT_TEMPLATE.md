# Template for Adding New Content to DART Tutorial

This file provides templates for adding new sections, figures, or content to the DART tutorial.

## Adding a New Figure

### Step 1: Prepare the Image
1. Create or capture your image
2. Save as PNG format
3. Name it descriptively (e.g., `fig19_new_feature.png`)
4. Place in the `images/` folder

### Step 2: Add to Tutorial
Insert in the .qmd file at the appropriate location:

```markdown
### Your New Section Title

Description of what this section covers...

![Detailed caption describing the figure](images/fig19_new_feature.png){#fig-new-feature}

As shown in @fig-new-feature, this feature allows you to...

::: callout-tip
## Additional Context
Extra information about this feature.
:::
```

### Step 3: Update Image Lists
Add to the figure list in:
- README.md
- FIGURE_REFERENCE.md
- IMAGE_EXTRACTION_GUIDE.md (if from PDF)

---

## Adding a New Section

### Major Section (Part)
```markdown
## Part N: Your Section Title

Brief introduction to what this part covers.

### Subsection 1

Content for first subsection...

### Subsection 2

Content for second subsection...
```

### Minor Section
```markdown
### Your Section Title

Content goes here. You can include:
- Lists
- Code blocks
- Figures
- Callouts

#### Optional Sub-subsection

More detailed content...
```

---

## Adding Step-by-Step Instructions

```markdown
### Performing Action X

Follow these steps to configure feature X:

1. Open the **Menu** 
2. Click on **Submenu → Option**
3. Configure the following settings:

**Parameter Configuration:**
- **Setting 1:** Value A
- **Setting 2:** Value B
- **Setting 3:** Value C

![Configuration interface showing these settings](images/figNN_name.png){#fig-label}

@fig-label demonstrates the complete configuration interface for feature X.

::: callout-important
## Critical Setting

Pay special attention to Setting 2, as incorrect values can cause [specific problem].
:::
```

---

## Adding a Comparison Table

```markdown
### Comparing Options

Different approaches have various trade-offs:

| Approach | Pros | Cons | Use Case |
|----------|------|------|----------|
| Method A | Fast, Simple | Limited accuracy | Quick tests |
| Method B | Accurate | Slow, Complex | Production runs |
| Method C | Balanced | Moderate complexity | General use |

: Comparison of different methods {#tbl-comparison}

As shown in @tbl-comparison, each approach has specific advantages.
```

---

## Adding a Code Example

```markdown
### Running a Custom Script

DART allows integration of custom scripts:

```bash
# Example shell script for batch processing
for sim in sim1 sim2 sim3; do
    dart --run $sim
    echo "Completed: $sim"
done
```

::: callout-note
## Script Location

Place custom scripts in the `DART/scripts/` directory for easy access.
:::
```

---

## Adding a Troubleshooting Section

```markdown
### Common Issue: Problem X

**Symptoms:**
- Error message or behavior description
- When this typically occurs

**Causes:**
- Potential cause 1
- Potential cause 2

**Solutions:**

1. **First Solution:**
   ```bash
   # Commands to fix
   ```
   This works because...

2. **Alternative Solution:**
   - Step-by-step approach
   - Verification method

::: callout-tip
## Prevention

To avoid this issue in the future, always [preventive action].
:::
```

---

## Adding a Best Practices Section

```markdown
### Best Practices for Feature X

::: panel-tabset
## Setup

**Initial Configuration:**
- Recommendation 1
- Recommendation 2

**Hardware Requirements:**
- Minimum specs
- Recommended specs

## Execution

**Preparation:**
- Pre-flight check 1
- Pre-flight check 2

**During Execution:**
- Monitor these parameters
- Watch for warning signs

## Validation

**Quality Checks:**
- Visual inspection
- Numerical validation

**Documentation:**
- What to record
- How to organize results
:::
```

---

## Adding Advanced Topic

```markdown
### Advanced: Topic Title

::: callout-warning
## Advanced Users Only

This section covers advanced topics that may require:
- Deep understanding of radiative transfer
- Programming experience
- Significant computational resources
:::

**Background Theory:**

Explanation of the theoretical basis...

**Implementation:**

Step-by-step advanced procedure...

**Validation:**

How to verify the advanced method works correctly...

::: callout-note
## Further Reading

For more details on this topic, see:
- [Reference 1](https://example.com)
- [Reference 2](https://example.com)
:::
```

---

## Adding References/Citations

### Internal Cross-Reference
```markdown
As discussed in [Scene Configuration](#scene-configuration), the parameters...
```

### External Link
```markdown
For more information, see the [DART Manual](https://dart.omp.eu/documentation).
```

### Footnote Reference
```markdown
This parameter affects accuracy significantly.[^accuracy]

[^accuracy]: Studies by Smith et al. (2020) show that values below 0.1 
    result in degraded accuracy by up to 15%.
```

---

## Adding Supplementary Materials

### Downloadable Files
```markdown
### Additional Resources

Download the example files:
- [Example configuration file](files/example_config.xml)
- [Sample 3D model](files/sample_tree.obj)
- [Python processing script](files/process_results.py)
```

### Video Tutorial Reference
```markdown
### Video Walkthrough

For a visual demonstration of this process, see:

<iframe width="560" height="315" 
    src="https://www.youtube.com/embed/VIDEO_ID" 
    frameborder="0" allowfullscreen>
</iframe>

*Video 1: Setting up a forest scene in DART*
```

---

## Template Checklist

When adding new content, ensure:

- [ ] Content is accurate and tested
- [ ] Figures are properly numbered and referenced
- [ ] Cross-references work (@fig-label, @tbl-label)
- [ ] Callout boxes used appropriately
- [ ] Code examples are functional
- [ ] Links are not broken
- [ ] Spelling and grammar checked
- [ ] Consistent formatting with rest of tutorial
- [ ] Section appears in table of contents
- [ ] Images are in images/ folder with correct names

---

## Example: Adding a Complete New Section

Here's a complete example of adding a new section about a hypothetical feature:

```markdown
## Part 10: Advanced Sensor Configuration

This section covers advanced sensor configuration options for simulating 
specific remote sensing platforms.

### Sensor Parameters

Configure sensor-specific parameters:

1. Navigate to **Sensors** in the parameter tree
2. Click **Add → Custom Sensor**
3. Configure the following:

![Sensor configuration dialog showing spectral response functions](images/fig19_sensor_config.png){#fig-sensor-config}

**Key Parameters:**
- **Sensor name:** Your sensor identifier
- **Platform altitude:** Height above ground (m)
- **Field of view:** Angular coverage (degrees)
- **Spectral response:** Import sensor RSR file

@fig-sensor-config shows the complete sensor configuration interface.

::: callout-tip
## Sensor Response Functions

Import actual sensor spectral response functions for accurate 
simulation. Most satellite operators provide these in CSV format.
:::

### Validation Against Satellite Data

To validate your sensor configuration:

1. Acquire coincident satellite imagery
2. Run DART simulation with same illumination conditions
3. Compare spectral signatures

| Metric | Threshold | Typical Value |
|--------|-----------|---------------|
| RMSE   | < 5%      | 2-3%          |
| R²     | > 0.95    | 0.97-0.99     |

: Validation metrics for sensor simulation {#tbl-sensor-validation}

::: callout-important
## Atmospheric Correction

Ensure both satellite data and DART outputs are corrected to 
the same reflectance level (TOA or BOA) for valid comparison.
:::

### Case Study: Sentinel-2 Simulation

Here's a complete workflow for simulating Sentinel-2:

```bash
# Step 1: Import Sentinel-2 sensor configuration
dart-import-sensor sentinel2_rsr.csv

# Step 2: Run simulation
dart --run sentinel2_simulation

# Step 3: Export results
dart-export --format geotiff sentinel2_simulation
```

Results from this workflow are shown below:

![Simulated vs. actual Sentinel-2 imagery comparison](images/fig20_sentinel2_comparison.png){#fig-sentinel2}

---

*For questions about this new feature, contact the DART development team.*
```

---

## After Adding Content

1. **Render to check:** `quarto render DART_tutorial.qmd`
2. **Verify:**
   - Images display correctly
   - Cross-references work
   - No rendering errors
   - Table of contents updated
3. **Test navigation:** Click through all new links
4. **Proofread:** Check spelling and formatting

---

*This template can be adapted for any new content additions to the tutorial.*
