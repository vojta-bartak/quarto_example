# DART Forest Scene Tutorial - Quarto Version

This package contains the DART (Discrete Anisotropic Radiative Transfer) forest scene setup tutorial converted to Quarto markdown format (.qmd).

## 📁 Files Included

1. **DART_tutorial.qmd** - Main tutorial file in Quarto markdown format
2. **IMAGE_EXTRACTION_GUIDE.md** - Detailed guide for extracting images from the PDF
3. **extract_images.py** - Python script to automate image extraction from PDF
4. **README.md** - This file

## 🚀 Quick Start

### Step 1: Extract Images from PDF

You have two options:

#### Option A: Manual Screenshot (Recommended for best quality)

1. Open `IMAGE_EXTRACTION_GUIDE.md`
2. Follow the instructions to create screenshots from each page
3. Save images to an `images/` folder with the specified filenames

#### Option B: Automated Extraction

```bash
# Install required Python packages
pip install pdf2image pillow

# Run the extraction script
python extract_images.py DART_tutorial_CZU_summer_school.pdf
```

This will create an `images/` folder with all 18 figures extracted from the PDF.

⚠️ **Note:** Automated extraction may require manual cropping for better results.

### Step 2: Verify Images

Check that you have all required images:

```
images/
├── fig01_new_simulation.png
├── fig02_open_editor.png
├── fig03_basic_config.png
├── fig04_spectral_bands.png
├── fig05_bidirectional_params.png
├── fig06_products_config.png
├── fig07_leaves_optical.png
├── fig08_bark_optical.png
├── fig09_ground_optical.png
├── fig10_earth_scene.png
├── fig11_field_import.png
├── fig12_3d_model_import.png
├── fig13_leaves_config.png
├── fig14_woody_parts_config.png
├── fig15_complete_scene.png
├── fig16_atmosphere_config.png
├── fig17_run_modules.png
└── fig18_sequence_launcher.png
```

### Step 3: Render the Tutorial

Once images are in place, render the tutorial:

#### HTML Output (Recommended)

```bash
quarto render DART_tutorial.qmd --to html
```

This creates a self-contained HTML file with:
- Interactive table of contents
- Numbered sections
- Collapsible callout boxes
- Cross-referenced figures

#### PDF Output

```bash
quarto render DART_tutorial.qmd --to pdf
```

This creates a PDF version suitable for printing or offline reading.

#### Both formats

```bash
quarto render DART_tutorial.qmd
```

## 📋 Tutorial Content

The tutorial covers:

1. **Initial Setup** - File organization and simulation creation
2. **Core Parameters** - Atmosphere, spectral bands, and basic configuration
3. **Scene Configuration** - Spatial resolution and rendering parameters
4. **Optical Properties** - PROSPECT model for leaves, bark, and ground
5. **Earth Scene** - Dimensions, location, and boundary conditions
6. **3D Objects** - Importing tree models and configuring groups
7. **Atmosphere** (Optional) - Advanced atmospheric parameters
8. **Running Simulations** - Module execution and workflow
9. **Sequence Launcher** - Automated parameter sweeps for LUT generation

Plus extensive sections on:
- Best practices and troubleshooting
- Advanced topics
- Quality control
- Computational efficiency
- Validation approaches

## 📊 Tutorial Features

- **18 numbered figures** with detailed captions and cross-references
- **Callout boxes** for notes, tips, warnings, and important information
- **Structured tables** for parameter specifications
- **Panel tabsets** for organized presentation of related content
- **Code formatting** for file paths and parameter names
- **Hierarchical organization** with numbered sections
- **Comprehensive index** in table of contents

## 🔧 Requirements

### For Rendering

- [Quarto](https://quarto.org/docs/get-started/) (version 1.3 or later)
- For PDF output: LaTeX distribution (TinyTeX recommended)

### For Image Extraction (if using automated method)

- Python 3.6+
- pdf2image package
- Pillow package
- poppler-utils (system dependency)

## 📖 Using the Tutorial

### Viewing

After rendering to HTML, open `DART_tutorial.html` in any web browser. The HTML version includes:

- Responsive design for different screen sizes
- Syntax highlighting for code
- Interactive table of contents with smooth scrolling
- Print-friendly styling

### Editing

The `.qmd` file can be edited with:

- RStudio (with Quarto support)
- VS Code (with Quarto extension)
- Any text editor

The format uses standard Markdown with Quarto extensions for:

```markdown
::: callout-note
Notes appear in blue boxes
:::

::: callout-tip
Tips appear in green boxes
:::

::: callout-important
Important info appears in red boxes
:::

![Figure caption](path/to/image.png){#fig-label}
```

### Cross-referencing Figures

In the text, reference figures using `@fig-label`:

```markdown
As shown in @fig-new-simulation, the dialog allows...
```

This automatically creates clickable cross-references with proper numbering.

## 🎨 Customization

### Changing Theme

Edit the YAML header in `DART_tutorial.qmd`:

```yaml
format:
  html:
    theme: cosmo  # Try: flatly, journal, lumen, minty, etc.
```

### Adjusting Table of Contents

```yaml
format:
  html:
    toc: true
    toc-depth: 3  # Adjust depth (1-5)
```

### Code Folding

```yaml
format:
  html:
    code-fold: true  # Change to true to hide code by default
```

## 🐛 Troubleshooting

### Images not showing

1. Verify the `images/` folder is in the same directory as `DART_tutorial.qmd`
2. Check image filenames match exactly (case-sensitive)
3. Ensure images are PNG format

### Quarto not found

```bash
# Install Quarto
# macOS
brew install quarto

# Ubuntu/Debian
sudo apt-get install quarto-cli

# Or download from https://quarto.org/docs/get-started/
```

### PDF rendering fails

```bash
# Install TinyTeX
quarto install tinytex
```

### Python script fails

```bash
# Install dependencies
pip install pdf2image pillow

# Install poppler (system dependency)
# macOS
brew install poppler

# Ubuntu/Debian
sudo apt-get install poppler-utils
```

## 📚 Additional Resources

- [Quarto Documentation](https://quarto.org/docs/guide/)
- [Quarto Markdown Basics](https://quarto.org/docs/authoring/markdown-basics.html)
- [DART Official Website](https://dart.omp.eu/)
- [DART User Manual](https://dart.omp.eu/documentation)

## 📝 Notes

- The tutorial is based on DART version 5.10.5
- Screenshots are from the actual DART interface
- All parameter values are tested and validated
- The tutorial includes both beginner and advanced topics

## 🤝 Contributing

To improve this tutorial:

1. Edit the `.qmd` file
2. Add or update images as needed
3. Re-render to verify changes
4. Share the updated files

## 📄 License

This tutorial is based on the original DART_tutorial_CZU_summer_school.pdf. 
Please respect any original copyright and usage restrictions.

## ✉️ Contact

For questions about:
- DART software: Visit [DART website](https://dart.omp.eu/)
- This tutorial format: Check the Quarto documentation

---

*Last updated: [Date will be auto-generated when rendered]*
